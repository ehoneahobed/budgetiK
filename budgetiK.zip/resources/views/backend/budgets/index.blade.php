@extends('backend.admin_master')

@section('main_content')
    

    <div class="py-12 row">
        <div class="container">
            <div class="row col-md-12 mt-2">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Budgets
                </h2>
            </div>

            <div class="row">
                
                <div class="col-md-8">
                    <div class="card">
                        <!-- show alert message after successfully adding a new category -->
                        @if (session('success'))
                        
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>{{ session('success') }}</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
    
                        @endif

                        <div class="card-header">List of Budgets</div>
                           
                        
                        
                        <div class=" table-responsive">
                            <div style="overflow-x:auto;">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th scope="col" width='5%'>#</th>
                                        <th scope="col" width='40%'>Budget Name</th>
                                        <th scope="col" width='20%'>Start Date</th>
                                        <th scope="col" width='20%'>End Date</th>
                                        <th scope="col" width='15%'>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        @php ($i = 1)
                                        @foreach ($budgets as $budget)
                                            <tr>
                                                <td>{{ $i++ }}</td>
                                                <td>{{ $budget->budget_name }}</td>
                                                <td>{{ $budget->start_date }}</td>
                                                <td>{{ $budget->end_date }}</td>  
                                                <td>
                                                    
                                                      {{-- svg format icon for edit
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                                      </svg> --}}
                                                    <a href="{{ url('admin/budgets/edit/'.$budget->id) }}" data-toggle="tooltip" data-placement="top" title="View Budget Details"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                        <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                                                        <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                                                      </svg></a>
                                                    {{-- <a href="{{ url('admin/budgets/edit/'.$budget->id) }}" data-toggle="tooltip" data-placement="top" title="Delete Budget"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                      </svg></a>     --}}
                                                </td>      
                                            </tr>    
                                        
                                        
                                        @endforeach
                                       
                                    
                                    </tbody>
                                </table>
                            </div>
                            </div>
                            
                    </div>

                </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">Create A New Budget</div>
                            <div class="card-body">
                                <form action="{{ route('create.budget') }}" method="POST">
                                    @csrf
        
                                    <div class="mb-3">
                                      <label for="exampleInputEmail1" class="form-label">Budget Name</label>
                                      
                                      <input type="text" class="form-control" name="budget_name" placeholder="A name to identify your budget">
                                        @error('budget_name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror  
        
                                    </div>

                                    
                                    <div class="mb-3">
                                        {{-- <div class="input-group date" data-provide="datepicker"> --}}
                                            <label for="exampleInputEmail1" class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="start_date">
                                            <div class="input-group-addon">
                                                <span class="glyphicon glyphicon-th"></span>
                                            </div>
                                        {{-- </div> --}}
                                    </div>

                                    <div class="mb-3">
                                        {{-- <div class="input-group date" data-provide="datepicker"> --}}
                                            <label for="exampleInputEmail1" class="form-label">End Date</label>
                                            <input type="date" class="form-control" name="end_date">
                                            <div class="input-group-addon">
                                                <span class="glyphicon glyphicon-th"></span>
                                            </div>
                                        {{-- </div> --}}
                                    </div>
                                    

                                    
                                    <button type="submit" class="btn btn-primary">Create Budget</button>
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
       
    

@endsection