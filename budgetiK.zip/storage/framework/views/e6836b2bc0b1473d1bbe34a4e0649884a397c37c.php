<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>BudgetiK</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    
    </head>
    <body class="antialiased">
        <header class="p-3 bg-dark text-white">
            <div class="container">
                <div class="row">
                    <div class="col-md-10">
                        <a class="navbar-brand" href="#">
                            <img src="<?php echo e(asset('backend/assets/img/budgetik logo.png')); ?>" alt="BudgetiK" width="20%" >
                        </a>
                    </div>
                        
                
                        <div class="col-md-2 float-right">
                            
                
                                <!-- if statement for links    -->
                                    <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <a class="btn btn-outline-light me-2" href="<?php echo e(url('/dashboard')); ?>" >Dashboard</a></li>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"  class="btn btn-outline-light me-2">Login</a>
                
                                <?php if(Route::has('register')): ?>
                                    <a class="btn btn-warning" href="<?php echo e(route('register')); ?>">Sign up</a></li>
                                <?php endif; ?>
                                <?php endif; ?>
                        
                            <?php endif; ?> 
                
                    </div>
                    
                </div>
                
            </div>
          </header>

        

            <div class="container col-xxl-8 px-4 py-5">
                <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
                  <div class="col-10 col-sm-8 col-lg-6">
                    <img src="<?php echo e(asset('backend/assets/img/1.png')); ?>" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="700" height="500" loading="lazy">
                  </div>
                  <div class="col-lg-6">
                    <h1 class="display-5 fw-bold lh-1 mb-3">Keep an eye on where your money goes</h1>
                    <p class="lead">Did you know that the fastest way to reach your financial is to preplan or set your budgets whiles tracking exactly how you use the money?</p>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                      
                      <button type="button" class="btn btn-outline-secondary btn-lg px-4">Get Started For Free</button>
                    </div>
                  </div>
                </div>
              </div>
            
              <div class="bg-dark text-secondary px-4 py-5 text-center">
                <div class="py-5">
                  <h1 class="display-5 fw-bold text-white">What You Get From This Platform</h1>
                  <div class="col-lg-6 mx-auto">
                    <p class="fs-5 mb-4">With Budgetik, you  are able to create various budgets by forecasting your incomes and expenditure. You are then able to track the actual income you make and the exact expenditure you make.</p>
                    <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                      <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold">Login</a>
                      <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light btn-lg px-4">Register</a>
                    </div>
                  </div>
                </div>
              </div>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/index.blade.php ENDPATH**/ ?>