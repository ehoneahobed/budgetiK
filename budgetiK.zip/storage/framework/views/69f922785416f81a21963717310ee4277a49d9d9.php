

<?php $__env->startSection('main_content'); ?>

<div class="py-12 row">
    <div class="container">
        
        <h3>Transactional Expenditure</h3>
        <div class="row col-md-10 mt-4 ml-5">
            
            <div class="card col-md-12">
                <form action="<?php echo e(route('transactions.expense.show')); ?>" method="GET">
            
                    <div class="row mt-4 ml-3">
                        <div class="col-md-12" ><h6>Select Interval to view Expenditure</h6></div>
                        <br>
                        <div class="mb-3 col-md-4 offset-md-1">
                            <label for="exampleInputEmail1" class="form-label">From</label>
                            <input type="date" name="start_date" class="form-control" id="">
                        
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

                        </div>
                        <div class="mb-3 col-md-2"></div>

                        <div class=" mb-3 col-md-4">
                            <label for="exampleInputEmail1" class="form-label">To</label>
                            <input type="date" name="end_date" class="form-control" id="">
                        
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

                        </div>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary col-md-5 offset-md-4">View Expenses Between This Interval</button>
                </form><br>

            </div>
            
            
            <div class="card col-md-12 mt-5">
                <!-- show alert message if exists -->
                <?php if(session('success')): ?>
                        
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <?php endif; ?>

                <div class="card-header">Recently Added Transactional Expenditure</div>
                <div class="card-body">

                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">SL NO.</th>
                            <th scope="col">Category</th>
                            <th scope="col">Expenditure Description</th>
                            <th scope="col">Amount (<?php echo e($currency_symbol); ?>)</th>
                            <th scope="col">Date</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $expense_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="">
                                    <th scope="row">
                                        <?php echo e($i++); ?>

                                    </th>
                                    <td>
                                        <?php echo e($expense_source->category_id); ?>

    
                                    </td>
                                    <td>
                                        <?php echo e($expense_source->expense_desc); ?>

                                    </td>
                                    <td width='15%'>
                                        <?php echo e($expense_source->amount); ?>

                                    </td>
                                    <td>
                                        <?php echo e($expense_source->date); ?>

                                    </td>
                                    <td> 
                                  </td>      
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        </tbody>
                        
                    </table>
                    
                    
                    <?php echo e($expense_sources->links("pagination::bootstrap-4")); ?>

    
                   
                </div>
            </div>
        </div>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/transactions/expenditure/view_expense.blade.php ENDPATH**/ ?>