

<?php $__env->startSection('main_content'); ?>
<div class="py-12 row">
    <div class="container">
        <div class="row col-md-12 mt-2">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                
                Add Projected Expenditure to <?php echo e($selected_budget->budget_name); ?>

            </h2>

            <div class="col-md-8">
                <div class="card">
                    <!-- show alert message after successfully adding a new category -->
                    <?php if(session('success')): ?>
                    
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <?php endif; ?>

                    <div class="card-header">Projected Expenditure for current budget</div>
               
            

                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">SL NO.</th>
                        <th scope="col">Category</th>
                        <th scope="col">Expense Description</th>
                        <th scope="col">Budgeted Amount (<?php echo e($currency_symbol); ?>)</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $expense_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense_source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                                <th scope="row"><?php echo e($i++); ?></th>
                                <td>
                                    <?php echo e($expense_source->category); ?>


                                </td>
                                <td><?php echo e($expense_source->expense_desc); ?></td>
                                <td width='10%'>
                                    <?php echo e($expense_source->budgeted_amount); ?>

                                </td>
                                <td>
                                  <a href="#" data-toggle="tooltip" data-placement="top" title="Edit Income">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                      <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                      <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg></a>
                                  <a href="#" data-toggle="tooltip" data-placement="top" title="Delete Income"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                      <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                    </svg></a>    
                              </td>      
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    </tbody>
                    
                </table>
                
                
                <?php echo e($expense_sources->links("pagination::bootstrap-4")); ?>

                  
                
                

            </div>
            
        </div>


        <div class="col-md-4">
            <div class="card">
                <!-- show alert message if exists -->
                <?php if(session('success')): ?>
                        
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <?php endif; ?>

                <div class="card-header">Add Income</div>
                <div class="card-body">
                   <h4> <?php echo e($selected_budget->budget_name); ?></h4>
                    <form action="<?php echo e(route('budget.expense.save')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" class="form-control"  name="budget_id" value="<?php echo e($selected_budget->id); ?>">
                        
                        <div class="mb-3">
                          <label for="exampleInputEmail1" class="form-label">Expenditure Category</label>
                          <select class="form-control" name="category_id" id="">
                              <option value="" >Choose a category</option>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

                        </div>

                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Expenditure Description</label>
                            <textarea name="expense_desc" class="form-control" id="" cols="30" rows="5"></textarea>
                          
                              <?php $__errorArgs = ['expense_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="text-danger"> <?php echo e($message); ?> </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
  
                          </div>

                          <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Budgeted Amount (<?php echo e($currency_symbol); ?>)</label>
                            <input type="text" class="form-control" name="budgeted_amount">
                          
                              <?php $__errorArgs = ['budgeted_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="text-danger"> <?php echo e($message); ?> </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
  
                          </div>
                        
                        <button type="submit" class="btn btn-primary">Add Expense</button>
                      </form>
                </div>
            </div>
        </div>

    </div>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/budgets/add_expense.blade.php ENDPATH**/ ?>