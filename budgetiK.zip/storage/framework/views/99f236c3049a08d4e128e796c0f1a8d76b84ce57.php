

<?php $__env->startSection('main_content'); ?>

<div class="py-12 row">
    <div class="container">
        
        <h3>Transactional Income</h3>
        <div class="row col-md-12 mt-4 ml-5">
            
            <div class="card col-md-10">
                <!-- show alert message if exists -->
                <?php if(session('success')): ?>
                        
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(session('success')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <?php endif; ?>

                <div class="card-header">Add Transactional Income</div>
                <div class="card-body">
                   <h4> </h4>
                    <form action="<?php echo e(route('transaction.income.save')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3 col-md-5">
                          <label for="exampleInputEmail1" class="form-label">Income Category</label>
                          <select class="form-control" name="category_id" id="">
                              <option value="" >Choose a category</option>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"> <?php echo e($message); ?> </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

                        </div>

                        <div class="mb-3 col-md-12">
                            <label for="exampleInputEmail1" class="form-label">Income Description</label>
                            <textarea name="income_desc" class="form-control" id="" cols="30" rows="5"></textarea>
                          
                              <?php $__errorArgs = ['income_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="text-danger"> <?php echo e($message); ?> </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
  
                          </div>

                          <div class="mb-3 col-md-12 row">
                            <div class="col-md-4 ">
                                <label for="exampleInputEmail1" class="form-label">Amount (<?php echo e($currency_symbol); ?>)</label>
                                <input type="text" class="form-control" name="actual_amount">
                            
                                <?php $__errorArgs = ['actual_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                            </div>
                                
  
                            <div class="col-md-4 ml-5">
                                <label for="exampleInputEmail1" class="form-label">Date</label>
                                <input type="date" class="form-control" name="date">
                            
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
                            </div>
                          </div>
                        
                        <button type="submit" class="btn btn-primary">Add Income</button>
                      </form>
                </div>
            </div>
        </div>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/transactions/income/add_income.blade.php ENDPATH**/ ?>