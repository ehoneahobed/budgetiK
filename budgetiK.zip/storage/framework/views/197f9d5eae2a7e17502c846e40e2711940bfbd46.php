

<?php $__env->startSection('main_content'); ?>
    

    <div class="py-12 row">
        <div class="container">
            <div class="row col-md-12 mt-2">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Budgets
                </h2>
            </div>

            <div class="row">
                
                <div class="col-md-8">
                    <div class="card">
                        <!-- show alert message after successfully adding a new category -->
                        <?php if(session('success')): ?>
                        
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('success')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
    
                        <?php endif; ?>

                        <div class="card-header">List of Budgets</div>
                           
                        
                        
                        <div class=" table-responsive">
                            <div style="overflow-x:auto;">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th scope="col" width='5%'>#</th>
                                        <th scope="col" width='40%'>Budget Name</th>
                                        <th scope="col" width='20%'>Start Date</th>
                                        <th scope="col" width='20%'>End Date</th>
                                        <th scope="col" width='15%'>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($i = 1); ?>
                                        <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($budget->budget_name); ?></td>
                                                <td><?php echo e($budget->start_date); ?></td>
                                                <td><?php echo e($budget->end_date); ?></td>  
                                                <td>
                                                    
                                                      
                                                    <a href="<?php echo e(url('admin/budgets/edit/'.$budget->id)); ?>" data-toggle="tooltip" data-placement="top" title="View Budget Details"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                                        <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                                                        <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                                                      </svg></a>
                                                    
                                                </td>      
                                            </tr>    
                                        
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    
                                    </tbody>
                                </table>
                            </div>
                            </div>
                            
                    </div>

                </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">Create A New Budget</div>
                            <div class="card-body">
                                <form action="<?php echo e(route('create.budget')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
        
                                    <div class="mb-3">
                                      <label for="exampleInputEmail1" class="form-label">Budget Name</label>
                                      
                                      <input type="text" class="form-control" name="budget_name" placeholder="A name to identify your budget">
                                        <?php $__errorArgs = ['budget_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
        
                                    </div>

                                    
                                    <div class="mb-3">
                                        
                                            <label for="exampleInputEmail1" class="form-label">Start Date</label>
                                            <input type="date" class="form-control" name="start_date">
                                            <div class="input-group-addon">
                                                <span class="glyphicon glyphicon-th"></span>
                                            </div>
                                        
                                    </div>

                                    <div class="mb-3">
                                        
                                            <label for="exampleInputEmail1" class="form-label">End Date</label>
                                            <input type="date" class="form-control" name="end_date">
                                            <div class="input-group-addon">
                                                <span class="glyphicon glyphicon-th"></span>
                                            </div>
                                        
                                    </div>
                                    

                                    
                                    <button type="submit" class="btn btn-primary">Create Budget</button>
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
       
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/budgets/index.blade.php ENDPATH**/ ?>