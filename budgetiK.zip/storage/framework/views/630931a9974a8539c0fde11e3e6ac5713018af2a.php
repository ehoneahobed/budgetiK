<?php $__env->startSection('main_content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    
</div>



<br>
<div class="row">
    <div class="col-xl-10 col-md-10 mb-4 offset-md-1">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <p>
                    Let's get started creating your budget
                    <br><br>
                    <h6 style="color: red"><b>Follow the following instructions</b></h6>
                    <ol>
                        <li>Create various categories for your <a href="<?php echo e(asset(route('categories'))); ?>">income or expected income</a></li>
                        <li>Create various categories for your <a href="<?php echo e(asset(route('categories'))); ?>">expenses or expected expenses</a></li>
                        <li>Create a <a href="<?php echo e(asset(route('budgets'))); ?>">new budget</a></li>
                        <li>Add all expected <a href="<?php echo e(route('budget.income')); ?>">income</a> elements to the budget you created</li>
                        <li>Add all expected <a href="<?php echo e(route('budget.expense')); ?>">expenses</a> elements to the budget you created</li>
                    </ol>
                </p>
                

              </div>
        </div>
    </div>
</div>
<!-- Content Row -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/welcome.blade.php ENDPATH**/ ?>