

<?php $__env->startSection('main_content'); ?>

<div class="py-12 row">
    <div class="container">
        <div class="row col-md-12 mt-2">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Add Projected Expenditure to Budget
            </h2>
        </div>

        <div class="card">
            <!-- show alert message if exits-->
            <?php if(session('success')): ?>
                        
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

            <?php endif; ?>

            <h5 class="card-header">Choose a budget to set projected expenditure</h5>
            <div class="card-body">
              <h5 class="card-title">Budgets</h5>
              <p class="card-text">

                <form action="<?php echo e(route('budget.expense.new')); ?>" method="GET">
                   
                    <label for="exampleInputEmail1" class="form-label">Choose budget</label>
                    <select name="budget_id" id="" class="form-control">
                        <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($budget->id); ?>"><?php echo e($budget->budget_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
            
                    <?php $__errorArgs = ['budget_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"> <?php echo e($message); ?> </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    
                    <br>
                    <input type="submit" value="Add expense source to budget" class="btn btn-info">
                    
                </form>
              </p>
            </div>
          </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/budgets/expense.blade.php ENDPATH**/ ?>