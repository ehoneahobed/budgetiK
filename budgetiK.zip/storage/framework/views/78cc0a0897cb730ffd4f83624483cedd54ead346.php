<?php $__env->startSection('main_content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    
</div>

<h5 class="h5 mb-0 text-gray-800">Summaries for this month</h5>
<br>


<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-success">Total Income Earned</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <?php if(count($this_month_incomes)==0): ?>
                    <?php $total_income = 0.00; ?>
                        <span style="font-size: 15px"><?php echo e($currency); ?></span><span style="font-size: 30px"> <?php echo e(round($total_income)); ?> </span>
                <?php else: ?>
                    <?php $__currentLoopData = $this_month_incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    //convert all the income amount into an array so that I can subsequeently apply array sum on it
                        $inc_amount[] = $income->amount;
                    ?> 
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        
                    ?>
                    <span style="font-size: 30px"><?php echo e($currency); ?> <?php echo e(round($total_income =array_sum($inc_amount), 2)); ?> </span>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-danger">Total Amount Spent</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <?php if(count($this_month_expense)==0): ?>
                    <?php $total_expense = 0.00; ?>
                    <span style="font-size: 15px"><?php echo e($currency); ?></span> <span style="font-size: 30px"><?php echo e($total_expense); ?> </span>
                <?php else: ?>

                    <?php $__currentLoopData = $this_month_expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    //convert all the income amount into an array so that I can subsequeently apply array sum on it
                        $exp_amount[] = $expense->amount;
                    ?> 
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <span style="font-size: 15px"><?php echo e($currency); ?></span> <span style="font-size: 30px"> <?php echo e(round($total_expense = array_sum($exp_amount), 2)); ?> </span>
              <?php endif; ?>
            </div>
        </div>
    </div>

   

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card  shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-info">Outstanding Amount</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <?php
                    $outstanding_amount = ($total_income-$total_expense);
                ?>
            <span style="font-size: 15px"><?php echo e($currency); ?></span> <span style="font-size: 30px"> <?php echo e(round($outstanding_amount, 2)); ?> </span>
            
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card  shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-warning">% Income Spent</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
               <?php if($total_expense == 0 AND $total_income == 0): ?>
                  <?php $percent_income_spent = 0.00."%"; ?>
                  <span style="font-size: 25px"><?php echo e($percent_income_spent); ?> </span>
                <?php else: ?>
                <?php
                    $percent_income_spent = ($total_expense/$total_income)*100;
                ?>
                 <div style="font-size: 25px"> <?php echo e(round($percent_income_spent, 2)); ?>% 
                <?php endif; ?>

                <div class="progress progress-sm">
                    <div class="progress-bar 
                        <?php if(round($percent_income_spent, 2)>50): ?>
                            <?php echo e("bg-warning"); ?> //if more than 50% of income spent show warning color
                        <?php endif; ?>
                    
                        bg-info" role="progressbar"
                        style="width: <?php echo e(round($percent_income_spent,2)); ?>%" aria-valuenow="<?php echo e(round($percent_income_spent)); ?>" aria-valuemin="0"
                        aria-valuemax="100"></div>
                </div>
            </div>
           
            </div>
        </div>
    </div>
</div>

            <div class="card-body shadow mb-4">
              <div class="card-text col-md-4 ">

                    <form action="<?php echo e(route('dashboard.summary')); ?>" method="GET">
                        <label for="exampleInputEmail1" class="form-label">Choose budget to display details</label>
                        <select name="budget_id" id="" class="form-control">
                            <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($budget->id); ?>"><?php echo e($budget->budget_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['budget_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"> <?php echo e($message); ?> </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                        
                        <br>
                        <input type="submit" value="View Budget Details" class="btn btn-info">
                    </form>
                </div>
            </div>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <?php if(!isset($name_of_selected_budget)): ?>
        <?php $name_of_selected_budget = "No budget selected" ?>
    <?php else: ?>
    
                <h5 class="h5 mb-0 text-gray-800">Summaries for selected budget <h6>(<?php echo e($name_of_selected_budget); ?>)</h6></h5>
                
    <?php endif; ?>
</div>
<!-- Content Row -->
<div class="row col-md-12">

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Savings (On Budget)</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">

                            <?php if(count($selected_inc_projected)==0): ?>
                                <?php $total_projected_income = 0.00; ?>
                            <?php else: ?>   
                                
                                 
                                    <?php $__currentLoopData = $selected_inc_projected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projected_income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        //convert all the income amount into an array so that I can subsequeently apply array sum on it
                                            $projected_inc_amount[] = $projected_income->budgeted_amount;
                                        ?> 
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total_projected_income =array_sum($projected_inc_amount);
                                ?>
                            <?php endif; ?>

                            <?php if(count($selected_exp_projected)==0): ?>
                                <?php $total_projected_expense = 0.00; ?>
                            <?php else: ?> 
                                    
                                    <?php $__currentLoopData = $selected_exp_projected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projected_expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        //convert all the income amount into an array so that I can subsequeently apply array sum on it
                                            $projected_exp_amount[] = $projected_expense->budgeted_amount;
                                        ?> 
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $total_projected_expense =array_sum($projected_exp_amount); ?>
                            <?php endif; ?>

                            <?php
                               // calculating the savings
                               $savings = $total_projected_income - $total_projected_expense;
                           ?>

                           <span style="font-size: 20px"><?php echo e($currency); ?> <?php echo e(round($savings, 2)); ?> </span>
                           
                      

                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Income Generated</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php if(count($selected_inc_actual)==0): ?>
                                <?php $total_actual_income = 0.00; ?>
                            <?php else: ?>  
                            
                            <?php $__currentLoopData = $selected_inc_actual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actual_income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                //convert all the income amount into an array so that I can subsequeently apply array sum on it
                                    $actual_inc_amount[] = $actual_income->amount;
                                ?> 
                           
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php
                              $total_actual_income =array_sum($actual_inc_amount); ?>
                            <?php endif; ?>
                            
                            <?php if($total_actual_income ==0 AND $total_projected_income ==0): ?>
                                <?php echo e($percent_inc_generated = 0.00); ?>

                            <?php else: ?>
                            <?php
                            // calculating percentage income generated
                              $percent_inc_generated = ($total_actual_income/$total_projected_income)*100;
                              echo round($percent_inc_generated, 2);
                           ?>
                            %
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-percent  fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Budget Spent (Percent)
                        </div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                    <?php if(count($selected_exp_actual)==0): ?>
                                        <?php $total_actual_expense = 0.00; ?>
                                    <?php else: ?>  
                                            
                                    
                                    <?php $__currentLoopData = $selected_exp_actual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actual_expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    //convert all the income amount into an array so that I can subsequeently apply array sum on it
                                        $actual_exp_amount[] = $actual_expense->amount;
                                    ?> 
                       
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total_actual_expense =array_sum($actual_exp_amount); ?>
                                    <?php endif; ?>
                                    
                                    <?php if($total_actual_expense ==0 AND $total_projected_expense ==0): ?>
                                        <?php echo e($pbs = 0); ?>

                                    <?php else: ?>
                                    <?php
                                    // calculating percentage budget spent
                                        $percent_budget_spent = ($total_actual_expense/$total_projected_expense)*100;
                                        echo $pbs = round($percent_budget_spent, 2);
                                    ?>
                                        %
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar
                                    <?php if($pbs<25): ?>
                                    <?php echo e("bg-success"); ?> //if less than 75% of income spent show success color

                                    <?php elseif($pbs>50 && $pbs<75): ?>
                                    <?php echo e("bg-warning"); ?> //if more than 50% but less then 75% of income spent show warning color

                                    <?php elseif($pbs>75): ?>
                                    <?php echo e("bg-danger"); ?> //if more than 75% of income spent show danger color

                                    <?php else: ?>
                                    <?php echo e("bg-info"); ?> //if less than 50% but greater than 25% of income spent show info color
                                <?php endif; ?>
                                    
                                    " role="progressbar"
                                        style="width: <?php echo e($pbs); ?>%" aria-valuenow="<?php echo e($pbs); ?>" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Expenses Incurred</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($currency); ?> <?php echo e(round($total_actual_expense, 2)); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-dollar-sign  fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-6 col-md-12 mb-4">
        <div class="card shadow h-100 py-1">
            <div class="card-header">
                <h6>Summary of income earned grouped by categories</h6>
            </div>
            <div class="card-body">
                
                <canvas id="incChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div> 
    <div class="col-xl-6 col-md-12 mb-4">
        <div class="card shadow h-100 py-1">
            <div class="card-header">
                <h6>Summary of expenses grouped by categories</h6>
            </div>
            <div class="card-body">
                
                <canvas id="expChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>  
</div>


<!-- Content Row -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@3.4.1/dist/chart.min.js"></script>
<script>
    var ctx = document.getElementById('incChart').getContext('2d');
    var incChart = new Chart(ctx, {
        type: 'bar',
        data: {
 //           labels: ["Red", "Blue", "Yellow"],
            //labels: ["Service Fee - Web Design","Test 1","test 3"],
            labels: <?php echo json_encode($list_of_inc_categories); ?>,
            datasets: [{
                label: 'Income Earned Per Category',
                //data: [12, 19, 3],
                data: <?php echo json_encode($amount_per_inc_category); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });


    // script for the expenses chart
    var exCx = document.getElementById('expChart').getContext('2d');
    var expChart = new Chart(exCx, {
        type: 'bar',
        data: {
 //           labels: ["Red", "Blue", "Yellow"],
            //labels: ["Service Fee - Web Design","Test 1","test 3"],
            labels: <?php echo json_encode($list_of_exp_categories); ?>,
            datasets: [{
                label: 'Expenses made Per Category',
                //data: [12, 19, 3],
                data: <?php echo json_encode($amount_per_exp_category); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 2)',
                    'rgba(54, 162, 235, 2)',
                    'rgba(255, 206, 86, 2)',
                    'rgba(75, 192, 192, 2)',
                    'rgba(153, 102, 255, 2)',
                    'rgba(255, 159, 64, 2)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/dashboard.blade.php ENDPATH**/ ?>