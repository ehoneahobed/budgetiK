

<?php $__env->startSection('main_content'); ?>
    

    <div class="py-12 row">
        <div class="container">
            <div class="row col-md-12 mt-2">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    Edit Catgory
                </h2>
            </div>

            <div class="row">
                
                <div class="col-md-12">
                   
                        <!-- show alert message after successfully adding a new category -->
                        <?php if(session('success')): ?>
                        
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session('success')); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
    
                        <?php endif; ?>

                           
                        
                        
                        
                    <div class="col-md-8 offset-md-2">
                        <div class="card">
                            <div class="card-body">
                                
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(url('admin/category/update/'.$category->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="mb-3">
                                      <label for="exampleInputEmail1" class="form-label">Category Name</label>
                                      
                                      <input type="text" class="form-control" name="category_name" value="<?php echo e($category->category); ?>">
                                        <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
        
                                    </div>

                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Category Description</label>
                                        
                                        <textarea type="text" class="form-control" name="category_description" ><?php echo e($category->cat_description); ?></textarea>
                                          <?php $__errorArgs = ['category_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="text-danger"><?php echo e($message); ?></span>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
          
                                      </div>
                                    
                                      <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Category Type</label>
                                        
                                        <select name="category_type" id="category_type" class="form-control">
                                            <option value="<?php echo e($category->cat_type); ?>"><?php echo e($category->cat_type); ?></option>
                                            <option value="Cash Out">Cash Out</option>
                                        </select>
                
                                          <?php $__errorArgs = ['category_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                              <span class="text-danger"><?php echo e($message); ?></span>
                                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
          
                                      </div>
                                   

                                    
                                    

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="submit" class="btn btn-primary">Update Category</button>
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
       
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel projects\budgetPT\resources\views/backend/category/edit.blade.php ENDPATH**/ ?>